<?php
// Membuat koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "belajar_login");

// Memeriksa koneksi
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>

