<?php
session_start();

require_once "koneksi.php";

// Periksa apakah koneksi database tersedia
if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Debugging untuk memeriksa status koneksi


// Mengambil data dari form
$username = $_POST['username'];
$password = $_POST['password'];

// Mempersiapkan dan mengeksekusi query
// $stmt = $conn->prepare("SELECT id, username, password FROM tb_user WHERE username = ?");
// $stmt->bind_param("s", $username);
// $stmt->execute();
// $result = $stmt->get_result();
;

$query = "SELECT * FROM tb_user WHERE username='$username' AND password='$password'";
$res = mysqli_query($conn, $query);

// Memeriksa apakah user ditemukan dan password cocok
if (mysqli_num_rows($res)>0) {
    // Menyimpan data user ke session
    $user = mysqli_fetch_array($res);
    $_SESSION['auth_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['psssword'] = $user['password'];
    header("Location: index.php"); // Mengarahkan ke halaman selamat datang
    exit();
} else {
    echo "Username atau password salah";
}

// Menutup koneksi
mysqli_close($conn);
?>
